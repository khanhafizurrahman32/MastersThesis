

A template for proposal and thesis documents in the Model Management working group.
This is just a rough template. Feel free to modify and change it to your own needs.
There are no strict guidelines, as long as your final text looks fine and is readable.

Most important files:
thesis.tex: the main file for a thesis
proposal.tex: the main file for a proposal document
make.bat: an example batch file to invoke pdflatex & bibtex
